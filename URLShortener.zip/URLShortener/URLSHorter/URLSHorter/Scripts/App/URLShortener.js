﻿
var app = angular.module('urlapp', [])
    .controller('urlShortenerCtrl', function ($scope) {
        
        $scope.user = {
            shortenButton: true,
            shortenText :""
        }
        if (sessionStorage.getItem("userId") == "" || sessionStorage.getItem("userId") == null) {
            $(".dashboard").hide();
            $(".login").show();
            
        }
        else {
            $(".dashboard").show();
            $(".login").hide();
        }
        $scope.UrlShown = false;

        $scope.shortenerChange = function () {
            url_validate = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
            if (url_validate.test($scope.user.shortenText) && $scope.user.shortenText!="") {
                $scope.user.shortenButton = false;
            }
            else {
                $scope.user.shortenButton = true;
            }
        }
        $(document).ready(function () {
            $('#datetimepicker1').datetimepicker({ format: 'DD/MM/YYYY', minDate: moment() });
        });

        $scope.CopyUrl = function (element) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).text()).select();
            document.execCommand("copy");
            $temp.remove();
        }

        $scope.ShortURL = function () {
            var userId = "1";
;            var Url = $scope.user.shortenText;
            var disableCount = $(".disableCount").val();
            var date = $('#datetimepicker1').data('date');
            if (date == undefined) {
                date = null;
            }
            if (disableCount == '') {
                disableCount = 0;
            }
 
            var UrlReques = {
                url: Url,
                DisableCount: disableCount,
                ExpiryDate: date,
                UserId: userId
                };
            $.ajax({
                url: 'http://localhost:57978/api/UrlShort/',
                type: 'POST',
                data: UrlReques,
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function (response) {
                    var res = JSON.parse(response);
                    $scope.$apply(function () {
                        if (res.IsSuccess) {
                            $scope.shortenedURL = res.ShortUrl;
                            $scope.UrlShown = true;
                        }
                    }, 500);
               
                },
                error: function (er) {
                    alert("error");
                }
            });
        }

        $(".logOut").on('click', function (event) {
            sessionStorage.removeItem("userId");
        });
        
});