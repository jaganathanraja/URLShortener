﻿angular.module('urlappdd', ["ejangular"])
    .controller('dashboardCtrl', function ($scope) {
        $scope.srtDateValue = new Date(); // sets the current date
        $scope.endDateValue = new Date(); // sets the current date
        $scope.dateFormat = "dd/MM/yyyy"; // sets the date format
        $(function () {
        
        });

        if (sessionStorage.getItem("userId") == "" || sessionStorage.getItem("userId") == null) {
            $(".dashboard").hide();
            $(".login").show();

        }
        else {
            $(".dashboard").show();
            $(".login").hide();
        }

        $scope.srtDateValueChange = function () {
            $scope.gettingURLtrackerDetails();
        }
        $scope.endDateValueChange = function () {
            $scope.gettingURLtrackerDetails();
        }
        $scope.data = [{
            Url: 'Hello'}
            
        ];

        $scope.gettingURLtrackerDetails = function () {
            $.ajax({
                url: '/UrlShort/GetURLTracker?srtDateTime=' + $scope.srtDateValue + "&endDateTime" + $scope.endDateValue,
                type: 'GET',
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function (response) {
                    debugger;
                },
                error: function (er) {
                    alert("error");
                }
            });
        }
        var obj = [
            { "XValue": 7, "YValue1": 28, "YValue2": 31, "YValue3": 36, "YValue4": 39 },
            { "XValue": 8, "YValue1": 32, "YValue2": 36, "YValue3": 42, "YValue4": 45 },
            { "XValue": 9, "YValue1": 25, "YValue2": 28, "YValue3": 32, "YValue4": 36 },
            { "XValue": 10, "YValue1": 27, "YValue2": 36, "YValue3": 41, "YValue4": 44 },
            { "XValue": 11, "YValue1": 35, "YValue2": 39, "YValue3": 42, "YValue4": 48 } ,
            { "XValue": 12, "YValue1": 26, "YValue2": 30, "YValue3": 34, "YValue4": 40 }                                              
        ];

        $scope.dataSource = obj;

        var objBar = [{ x: 27, y1: 7, y2: 9 },     
        { x: 28, y1: 8 }        
        ];

        $scope.dataSourceBar = objBar;
        $scope.displaytext = "OndataLabel";
        $scope.marker = {
            dataLabel:
            {
                font: { size: '13px', fontFamily: 'Segoe UI', fontStyle: 'Normal', fontWeight: 'regular' },
                textPosition: 'top',
                angle: -45, visible: true
            },
        };

        var objPie = [{ x: 'Google Chrome', y: 68, text: 'Google Chrome, 68.47%' },
            { x: 'Firefox', y: 28, text: 'Firefox, 28.49%' },
            { x: 'Microsoft Edge', y: 12, text: 'Microsoft Edge, 12.40%' },
            { x: 'Safari', y: 1, text: 'Safari, 0.44%' },
            { x: 'Internet Explorer', y: 1, text: 'Internet Explorer, 0.11%' },
            { x: 'Opera', y: 6, text: 'Opera, 0.06%' }];

        $scope.objPie = objPie;
        $scope.displaytextrender = "displayTextRender";
        $scope.piemarker = { dataLabel: { visible: true, shape: 'none', connectorLine: { type: 'bezier', color: 'black' }, font: { size: '14px' } } };

        $(".logOut").on('click', function (event) {
            sessionStorage.removeItem("userId");
        });

    });