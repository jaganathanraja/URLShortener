﻿
var app = angular.module('LoginApp', [])
    .controller('loginCtrl', function ($scope) {

        $scope.User = {
            UserName: "",
            Password:""
        }

        $scope.UserSubmitButton = true;

       
        $scope.LoginBtnClick = function () {

            var users = {
                Username: $scope.User.UserName,
                Password: $scope.User.Password,
            }
            $.ajax({
                url: '/User/Login',
                type: 'POST',
                data: users,
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function (response) {
                    if (response.status == "Successfully logged") {
                        var userId = response.data.UserId;
                        sessionStorage.setItem("userId", userId);
                        window.location.href = "/Home/Index";
                    }
                    else {
                        alert(response.status);
                    }
                },
                error: function (er) {
                    alert("error");
                }
            }); 

        }

        $scope.ValidateSignInForm = function () {
            if ($scope.User.UserName != "" && $scope.User.Password != "") {
                $scope.UserSubmitButton = false;
            }
            else {
                $scope.UserSubmitButton = true;
            }
        }

    });