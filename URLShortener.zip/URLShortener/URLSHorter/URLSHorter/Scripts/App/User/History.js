﻿angular.module('urlappdd', ["ejangular"])
    .controller('dashboardCtrl', function ($scope) {

        $scope.data = [];
        if (sessionStorage.getItem("userId") == "" || sessionStorage.getItem("userId") == null) {
            $(".dashboard").hide();
            $(".login").show();

        }
        else {
            $(".dashboard").show();
            $(".login").hide();
        }

        
        $(".logOut").on('click', function (event) {
            sessionStorage.removeItem("userId");
        });

        $.ajax({
            url: 'http://localhost:57978/api/UrlShort/GetURLHistory?userId=1',
            type: 'GET',
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            success: function (response) {
                if (response.status == "Successfully logged") {
                  
                }
                else {
                    alert(response.status);
                }
            },
            error: function (er) {
                alert("error");
            }
        }); 

    });