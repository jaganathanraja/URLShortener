﻿
var app = angular.module('SignUpApp', [])
    .controller('SignUpCtrl', function ($scope) {

        $scope.User = {
            FirstName :"",
            LastName: "",
            UserName: "",
            EmailAddress: "",
            Password: ""
        }

        $scope.UserSubmitButton = true;


        $scope.SignUpClick = function () {

            var users = {
                FirstName: $scope.User.FirstName,
                LastName: $scope.User.LastName,
                UserName: $scope.User.UserName,
                Email: $scope.User.EmailAddress,
                Password: $scope.User.Password
            }
            $.ajax({
                url: '/User/SaveUser',
                type: 'POST',
                data: users,
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function (response) {
                    if (response.status == "User added Successfully") {
                
                        $scope.$apply(function () {
                            $scope.User.FirstName = "";
                            $scope.User.LastName = "";
                            $scope.User.UserName = "";
                            $scope.User.EmailAddress = "";
                            $scope.User.Password = "";
                            $scope.UserSubmitButton = true;
                        }, 1000);
                        alert(response.status);
                        
                    }
                    else {
                        alert(response.status);
                    }
                },
                error: function (er) {
                    alert("error");
                }
            });

        }

        $scope.ValidateSignInForm = function () {
            var pattern = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,9}|[0-9]{1,3})(\]?)$/;
            $scope.isValidEmailAddress = pattern.test($scope.User.EmailAddress);
            if ($scope.User.FirstName != "" && $scope.User.LastName != "" && $scope.isValidEmailAddress && $scope.User.Username != "" && $scope.User.EmailAddress != "" && $scope.User.Password != "" && $scope.User.Password.length >= 6) {
                $scope.UserSubmitButton = false;
            }
            else {
                $scope.UserSubmitButton = true;
            }
        }

    });