﻿
var app = angular.module('ForgetPasswordApp', [])
    .controller('ForgetPasswordCtrl', function ($scope) {

        $scope.User = {
            UserName: "",
            Password: ""
        }

        $scope.ChangePasswordButton = true;


        $scope.SavePasswordClick = function () {

            var users = {
                UserName: $scope.User.UserName,
                NewPassword: $scope.User.Password
            }
            $.ajax({
                url: '/User/SavePassword',
                type: 'POST',
                data: users,
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function (response) {
                    if (response.status == "Password changed Successfully") {
                        $scope.$apply(function () {
                            $scope.User.UserName = "";
                            $scope.User.Password = "";
                            $scope.ChangePasswordButton = true;
                        }, 1000);
                        alert(response.status);

                    }
                    else {
                        alert(response.status);
                    }
                },
                error: function (er) {
                    alert("error");
                }
            });

        }

        $scope.ValidatePasswordForm = function () {
            if ($scope.User.Username != "" && $scope.User.Password != "" && $scope.User.Password.length >= 6) {
                $scope.ChangePasswordButton = false;
            }
            else {
                $scope.ChangePasswordButton = true;
            }
        }

    });