﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using URLSHorter.Models.Repo;
using URLSHorter.Models.Request;

namespace URLSHorter.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Login()
        {          
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginUserRequest users)
        {
            UsersRepo repo = new UsersRepo();
            var userResponse = repo.Login(users);
            if (userResponse != null)
            {
                return base.Json(new
                {
                    success = true,
                    status = "Successfully logged",
                    data = userResponse
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return base.Json(new
                {
                    success = false,
                    status = "User name or Email invalid",
                }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult Home()
        {
            UsersRepo repo = new UsersRepo();
            //  repo.Login();
            return View();
        }

        public ActionResult SignUp(Users users)
        {
            return View();
        }

        public ActionResult SaveUser(Users users)
        {
            UsersRepo repo = new UsersRepo();
            var userResponse = repo.SignUpUsers(users);
                return base.Json(new
                {
                    success = true,
                    status = userResponse
                }, JsonRequestBehavior.AllowGet);
            //  repo.Login();

        }
        public ActionResult ForgotPassword()
        {
            return View();
        }
        public ActionResult SavePassword(ForgotPasswordRequest requset)
        {
            UsersRepo repo = new UsersRepo();
            var userResponse = repo.ForgotPassword(requset);
            return base.Json(new
            {
                success = true,
                status = userResponse
            }, JsonRequestBehavior.AllowGet);
        }
    }
}