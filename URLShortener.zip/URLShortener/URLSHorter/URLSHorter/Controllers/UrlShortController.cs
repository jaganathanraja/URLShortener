﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using URLSHorter.Models;
using URLSHorter.Models.Repo;
using URLSHorter.Models.Request;

namespace URLSHorter.Controllers
{
    public class UrlShortController : ApiController
    {

        [HttpGet]

        public string res()
        {
            return "true";
        }

        [HttpPost]
        public HttpResponseMessage ShortUrl()
        {
            UrlResponse result = new UrlResponse();
            try
            {
                var httpContext = (HttpContextBase)Request.Properties["MS_HttpContext"];
                if (!httpContext.Request.Form.AllKeys.Any())
                {
                    var data = Request.Content.ReadAsStringAsync().Result;
                    var requestData = JsonConvert.DeserializeObject<UrlReques>(data);
                    var shortUrl = new UrlRepo().GetShortUrl(requestData);
                    result.RealUrl = requestData.url;
                    result.ShortUrl = Request.RequestUri.GetLeftPart(UriPartial.Authority) + "/" + shortUrl;
                    result.IsSuccess = true;

                }
                else
                {
                    var formData = GetFormData(httpContext);
                    var settings = new JsonSerializerSettings
                    {
                        ContractResolver = new CamelCasePropertyNamesContractResolver()
                    };
                    var data = JsonConvert.SerializeObject(formData, settings);

                    var format = "dd/MM/yyyy"; // your datetime format
                    var dateTimeConverter = new IsoDateTimeConverter { DateTimeFormat = format };
                    var requestData = JsonConvert.DeserializeObject<UrlReques>(data, dateTimeConverter);
                    var shortUrl = new UrlRepo().GetShortUrl(requestData);
                    result.RealUrl = requestData.url;
                    result.ShortUrl = Request.RequestUri.GetLeftPart(UriPartial.Authority) + "/" + shortUrl;
                    result.IsSuccess = true;
                }

                return Request.CreateResponse(JsonConvert.SerializeObject(result));
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
                return Request.CreateResponse(JsonConvert.SerializeObject(result));
            }
        }

        private Dictionary<string, string> GetFormData(HttpContextBase context)
        {
            return context.Request.Form.Keys.Cast<string>().ToDictionary(key => key, key => context.Request.Form[key]);
        }

        [HttpGet]
        public HttpResponseMessage GetURLTracker(DateTime srtDateTime, DateTime endDateTime)
        {
            URLTrackerResponse response = new URLTrackerResponse();
            try
            {
                UrlRepo repo = new UrlRepo();
                var result = repo.GetURLTrackerResponse(srtDateTime, endDateTime);
                return Request.CreateResponse(JsonConvert.SerializeObject(result));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public HttpResponseMessage GetURLHistory(int userID)
        {
            URLHistory response = new URLHistory();
            try
            {
                UrlRepo repo = new UrlRepo();
                var result = repo.GetURLHistory(userID);
                return Request.CreateResponse(JsonConvert.SerializeObject(result));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public HttpResponseMessage DeleteUrl(int id)
        {
            try
            {
                UrlRepo repo = new UrlRepo();
                var result = repo.DeleteUrl(id);
                return Request.CreateResponse(JsonConvert.SerializeObject(result.ToString()));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
