﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using URLSHorter.Models.Repo;

namespace URLSHorter.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("UrlForm");
        }

        public ActionResult TinyUrl(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    var ip = GetIPAddress();
                    HttpRequest req = System.Web.HttpContext.Current.Request;
                    var browserName = req.Browser.Browser;
                    var result = new UrlRepo().GetRealUrl(id, new Models.Request.TrackRequest() { BrowserName = browserName, IpAddress = ip });
                    return Redirect(result);
                }
                else
                    return RedirectToAction("UrlForm");
            }
            catch(Exception ex)
            {
                if(ex is IndexOutOfRangeException)
                {
                    ViewBag.Message = "Url exceed the limit of counts, May offer or contest has been completed";
                    return View("Error");
                }
                else if(ex is ArgumentOutOfRangeException)
                {
                    ViewBag.Message = "Url has been expired";
                    return View("Error");
                }
                else if(ex is KeyNotFoundException)
                {
                    ViewBag.Message = "Url not found";
                    return View("Error");
                }
                else
                {
                    ViewBag.Message = ex.Message;
                    return View("Error");
                }
            }
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        protected string GetIPAddress()
        {
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return context.Request.ServerVariables["REMOTE_ADDR"];
        }

        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult History()
        {
            return View();
        }

        public ActionResult UrlForm()
        {
            return View();
        }

        public ActionResult UrlList()
        {
            return View();
        }
    }
}