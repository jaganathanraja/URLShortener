﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace URLSHorter.Models.Request
{
    public class TrackRequest
    {
        public int UrlId { get; set; }
        public string BrowserName { get; set; }
        public string IpAddress { get; set; }
        public string CountryName { get; set; }
    }
}