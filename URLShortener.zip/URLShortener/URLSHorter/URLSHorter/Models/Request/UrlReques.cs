﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace URLSHorter.Models.Request
{
    public class UrlReques
    {
        public string url { get; set; }
        public int? DisableCount { get; set; }

        public DateTime? ExpiryDate { get; set; }
        public int UserId { get; set; }
    }
}