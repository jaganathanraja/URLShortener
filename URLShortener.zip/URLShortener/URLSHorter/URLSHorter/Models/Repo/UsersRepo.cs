﻿using System;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using URLSHorter.Models.Request;
using URLSHorter.Models.Response;

namespace URLSHorter.Models.Repo
{
    public class UsersRepo
    {
        public String SignUpUsers(Users user)
        {
            string message = "";
            if (user != null)
            {
                using (UrlShortenEntities context = new UrlShortenEntities())
                {
                    var ExistUser = context.SystemUsers.Where(u => u.UserName.ToLower() == user.Username.ToLower() || u.EmailAddress.ToLower() == user.Email).FirstOrDefault();
                    if(ExistUser == null)
                    {
                        SystemUser newUser = new SystemUser()
                        {
                            FirstName = user.FirstName,
                            LastName = user.LastName,
                            EmailAddress = user.Email,
                            UserName = user.Username,
                            Password = user.Password
                        };
                        context.SystemUsers.Add(newUser);
                        context.SaveChanges();
                        SendEmail(user);
                        message = "User added Successfully";
                    }
                    else
                    {
                        if(ExistUser.UserName.ToLower() == user.Username.ToLower())
                        {
                            message = "User name is already exist";
                        }
                        else if(ExistUser.EmailAddress.ToLower() == user.Email.ToLower())
                        {
                            message = "Email address is already exist";
                        }
                    }
                }
            }
            return message;
        }

        public UserResponse Login(LoginUserRequest user)
        {
            UserResponse response = new UserResponse();
            using (UrlShortenEntities context = new UrlShortenEntities())
            {
                var u = context.SystemUsers.Where(w => (w.UserName == user.Username || w.EmailAddress == user.Username) && w.Password == user.Password).FirstOrDefault();
                if (u != null)
                {
                    response.FirstName = u.FirstName;
                    response.LastName = u.LastName;
                    response.Email = u.EmailAddress;
                    response.Username = u.UserName;
                    response.UserId = u.Id;
                }
                else
                {
                    return null;
                }
            }
            return response;
        }

        public string ForgotPassword(ForgotPasswordRequest requset)
        {
            string message = "";
            using(UrlShortenEntities context = new UrlShortenEntities())
            {
                SystemUser user = context.SystemUsers.Where(w => (w.UserName == requset.UserName)).FirstOrDefault();
                if (user != null)
                {
                    user.Password = requset.NewPassword;
                    context.SaveChanges();
                    Users u = new Users()
                    {
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        Email = user.EmailAddress,
                        Password = user.Password
                    };
                    message = "Password changed Successfully";
                    SendEmail(u);
                }
                else
                {
                    message = "User does not exist";
                }
            }
            return message;
        }

        private async Task SendEmail(Users user)
        {
            await Task.Run(() =>
            {
                using (MailMessage mail = new MailMessage())
                {
                    SmtpClient smtpServer = new SmtpClient();
                    mail.From = new MailAddress("developmentconsulting@syncfusion.com");
                    mail.To.Add(user.Email);
                    mail.Subject = "Password changed!!!";
                    mail.Body = "<div><p> Hi " + user.FirstName + " " + user.LastName + ",</p><p>Your password is changed</p><p>New password: " + user.Password + "</p><p> Thanks,</p><p>URLShorter</p></div>";
                    mail.IsBodyHtml = true;
                    smtpServer.Send(mail);
                }
            });
        }
    }
}