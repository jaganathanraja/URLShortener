﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using URLSHorter.Models.Request;

namespace URLSHorter.Models.Repo
{
    public class UrlRepo
    {
        public static readonly string StaticStrign = "a0b1c2d3e4f5g6h7i8j9klmnopqrstuvwxyz";
        public static readonly int BaseLength = StaticStrign.Length;

        public string GetShortUrl(UrlReques urlReques)
        {
            var realUrl = urlReques.url;
            var isNeedToUpdate = false;
            using (var entity = new UrlShortenEntities())
            {
                var result = entity.URLs.Where(a => a.ShortenURL.Equals(realUrl) || a.URL1.Equals(realUrl))?.FirstOrDefault();
                if (result != null)
                {
                    if ((result.DisableUserCount == null || result.URLTrackers.Count == 0 || result.URLTrackers.Count > result.DisableUserCount) && (result.ExpiredDate == null || result.ExpiredDate >= DateTime.Now))
                    {
                        return result.ShortenURL;
                    }
                    isNeedToUpdate = true;
                }

                var url = new URL();
                if (!isNeedToUpdate)
                {
                    url.URL1 = realUrl;
                    url.DisableUserCount = urlReques.DisableCount;
                    url.SystemUserId = urlReques.UserId;
                    url.ExpiredDate = urlReques.ExpiryDate;
                    entity.URLs.Add(url);
                    entity.SaveChanges();
                    url.ShortenURL = GenerateShortUrl(url.Id);
                }
                else
                {
                    url = result;
                    result.DisableUserCount = (urlReques.DisableCount != null && urlReques.DisableCount > 0) ? result.DisableUserCount + urlReques.DisableCount ?? 0 : 0;
                    result.ExpiredDate = urlReques.ExpiryDate != null ? urlReques.ExpiryDate : null;
                }
                entity.SaveChanges();
                return url.ShortenURL;
            }
        }

        public string GetRealUrl(string shortUrlKey, TrackRequest trackRequest)
        {
            var id = GetIdFromShortUrl(shortUrlKey);
            using (var entity = new UrlShortenEntities())
            {
                var result = entity.URLs.Where(a => a.Id.Equals(id))?.FirstOrDefault();
                if (result != null)
                {
                    var count = result.URLTrackers.Count();
                    if (count >= result.DisableUserCount)
                        throw new IndexOutOfRangeException("Count exceed");
                    if (result.ExpiredDate >= DateTime.Now)
                        throw new ArgumentOutOfRangeException("Date expired");
                    trackRequest.UrlId = result.Id;
                    UpdateTrack(trackRequest);
                    return result.URL1;
                }
                throw new KeyNotFoundException("Url not valid");

            }
        }

        public void UpdateTrack(TrackRequest trackRequest)
        {
            using (var entity = new UrlShortenEntities())
            {
                var track = new URLTracker();
                track.URLId = trackRequest.UrlId;
                track.Browser = trackRequest.BrowserName;
                track.IPAddress = trackRequest.IpAddress;
                track.Country = trackRequest.CountryName;
                track.CreatedDatetime = DateTime.Now;
                entity.URLTrackers.Add(track);
                entity.SaveChanges();
            }
        }

        public string GenerateShortUrl(int i)
        {
            if (i == 0) return StaticStrign[0].ToString();

            var s = string.Empty;

            while (i > 0)
            {
                s += StaticStrign[i % BaseLength];
                i = i / BaseLength;
            }

            return string.Join(string.Empty, s.Reverse());
        }

        public int GetIdFromShortUrl(string s)
        {
            var i = 0;

            foreach (var c in s)
            {
                i = (i * BaseLength) + StaticStrign.IndexOf(c);
            }

            return i;
        }

        public URLTrackerResponse GetURLTrackerResponse(DateTime srtDateTime, DateTime endDateTime)
        {
            URLTrackerResponse response = new URLTrackerResponse();
            using (UrlShortenEntities context = new UrlShortenEntities())
            {
                var groupByCountry = context.URLTrackers.GroupBy(g => g.Country).ToList();
            }
            return response;
        }

        public List<URLHistory> GetURLHistory(int userID)
        {
            List<URLHistory> response = new List<URLHistory>();
            using (UrlShortenEntities context = new UrlShortenEntities())
            {
                response = (from user in context.SystemUsers
                            join url in context.URLs on user.Id equals url.SystemUserId
                            where url.IsDeleted == false
                            select new URLHistory
                            {
                                Id = url.Id,
                                URL = url.URL1,
                                ShortenURL = url.ShortenURL,
                                ExpiredDate = url.ExpiredDate.Value,
                                DisableCount = url.DisableUserCount.Value
                            }).ToList();
            }
            return response;
        }

        public bool DeleteUrl(int id)
        {
            using (UrlShortenEntities context = new UrlShortenEntities())
            {
                var url = context.URLs.Where(a => a.Id == id)?.FirstOrDefault();
                if (url == null)
                    return true;
                url.IsDeleted = true;
                context.SaveChanges();
                return true;
            }            
        }
    }
}