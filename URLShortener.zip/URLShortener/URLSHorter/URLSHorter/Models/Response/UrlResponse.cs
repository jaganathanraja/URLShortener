﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace URLSHorter.Models
{
    public class UrlResponse
    {
        public string ShortUrl { get; set; }
        public string RealUrl { get; set; }
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }

    public class URLTrackerResponse
    {
        public int ListofUsedCountByCountry { get; set; }
        public string CountryName { get; set; }
        public int ListofUsedCountByBrowser { get; set; }
        public string BrowserName { get; set; }
    }

    public class URLHistory
    {
        public int Id { get; set; }
        public string URL { get; set; }
        public string ShortenURL { get; set; }
        public int Usercount { get; set; }
        public DateTime ExpiredDate { get; set; }
        public int DisableCount { get; set; }
        public bool IsDeleted { get; set; }
    }
}